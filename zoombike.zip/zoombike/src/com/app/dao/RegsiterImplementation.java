package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Admin;
import com.app.pojos.User;
@Repository
@Transactional
public class RegsiterImplementation implements RegsiterInterface {
	// dependency
		@Autowired // auto wiring by type
		private SessionFactory sf;

	@Override
	public String Regsiter(User u) {
		sf.getCurrentSession().save(u);
		return "Registration succesfull";
	}

	@Override
	public User auntheticateUser(String login, String password) {
		// TODO Auto-generated method stub
		String jpql="select u from User u where u.login = :login and u.password = :password";
		return sf.getCurrentSession().createQuery(jpql,User.class).setParameter("login", login).setParameter("password", password).getSingleResult();

	}

	@Override
	public Admin auntheticateAdmin(String login, String password) {
		String jpql="select u from Admin u where u.name = :login and u.password = :password";
		return sf.getCurrentSession().createQuery(jpql,Admin.class).setParameter("login", login).setParameter("password", password).getSingleResult();
	}
	
	


}
