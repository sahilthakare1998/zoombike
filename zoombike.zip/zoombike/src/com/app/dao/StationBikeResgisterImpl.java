package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Admin;
import com.app.pojos.Bikes;
import com.app.pojos.Logs;
import com.app.pojos.Station;
import com.app.pojos.User;
import com.mysql.cj.Query;
@Repository
@Transactional
public class StationBikeResgisterImpl implements StationBikeProcessInterface {
	@Autowired
	private SessionFactory sf;
	@Override
	public Station AddStation(Station s,String a) 
	{
		String jpql="select a from Admin a where a.name=:nm";
		Admin c = sf.getCurrentSession().createQuery(jpql, Admin.class).setParameter("nm", a).getSingleResult();
		c.addStation(s);
		return s;
	}
	@Override
	public Bikes AddBike(Bikes B, int id) 
	{
		String jpql="select a from Station a where a.id=:id";
	Station c = sf.getCurrentSession().createQuery(jpql, Station.class).setParameter("id", id).getSingleResult();
		c.addBikes(B);
		return B;
	}
	@Override
	public String  RemoveStation(int sid) 
	{	
		
	int count=0,count1=0;
		
		System.out.println("station to be deleted:"+sid);
		String jpq="delete from Bikes s where s.selectedstation.id=:sid";
		 org.hibernate.query.Query query=sf.getCurrentSession().createQuery(jpq).setParameter("sid", sid);
		 count=query.executeUpdate();
		String jpql="delete from Station s where s.id=:sid ";
		 org.hibernate.query.Query query1=sf.getCurrentSession().createQuery(jpql).setParameter("sid", sid);
		 count1=query1.executeUpdate();
		if(count>0 && count1>0)
		{
			System.out.println( "station deleted for ID "+sid);
			return "station deleted for ID "+sid;
		}
		System.out.println("station not found : Can't be deleted");
		return "station not found : Can't be deleted";
	}
	
	@Override
	public String RemoveBike(int sid,int bid) {
		int count=0;
		String jpql="delete from Bikes b where b.selectedstation.id=:sid and b.id=:bid ";
		 org.hibernate.query.Query query=sf.getCurrentSession().createQuery(jpql).setParameter("sid", sid).setParameter("bid",bid);
		 count=query.executeUpdate();
		if(count>0)
		{
			return "Bikes deleted for ID "+bid;
		}
		return "Bikes not found : Can't be deleted";
	}
	@Override
	public List<Station> StationList() {
		String jpql="select b from Station b";
		System.out.println("in station list");

		List<Station> slist =sf.getCurrentSession().createQuery(jpql,Station.class).getResultList();
		System.out.println(slist);
		return slist;
	}
	@Override
	public String updatestation(Station s,int id) {
			s.setId(id);
			Session hs1 = sf.getCurrentSession();
			hs1.update(s);
			return "upated";
	
	}
	@Override
	public String updatebike(Bikes s, int sid) {
		Session hs=sf.getCurrentSession();
			hs.update(s);
			return "bike for station ID "+sid+"upated";
	}
	@Override
	public Bikes checkBike(int sid,int bid) {
		String jpql="select  b from Bikes b where b.selectedstation.id=:sid and b.id=:bid ";
		return sf.getCurrentSession().createQuery(jpql,Bikes.class).setParameter("sid", sid).setParameter("bid",bid).getSingleResult();
}
	@Override
	public Station checkStation(int sid) {
		String jpql="select a from Station a where a.id=:id";
		Station c = sf.getCurrentSession().createQuery(jpql, Station.class).setParameter("id", sid).getSingleResult();
		return c;
	}
	@Override
	public Admin addadmin(String nm) {
		String jpql="select a from Admin a where a.name=:nm";
		Admin c = sf.getCurrentSession().createQuery(jpql, Admin.class).setParameter("nm", nm).getSingleResult();
		return c;
	}
	@Override
	public Station addupstation(int sid) {
		 
		String jpql="select a from Station a where a.id=:id";
		Station c = sf.getCurrentSession().createQuery(jpql, Station.class).setParameter("id",sid).getSingleResult();
		return c;
	}
	@Override
	public List<Bikes> BikeList() {
		String jpql="select b from Bikes b";
		System.out.println("in Bike list");

		List<Bikes> slist =sf.getCurrentSession().createQuery(jpql,Bikes.class).getResultList();
		System.out.println(slist);
		return slist;
	}
	@Override
	public Logs mainatainLogs(int uid, Bikes b, Station src, Station dst) 
	{
		Logs l=new Logs(src.getNumPoint(), dst.getNumPoint(),b.getVin(),b.getId(), uid);
		sf.getCurrentSession().save(l);
		return l;
	}
	@Override
	public boolean changestation(Bikes b, Station dst) {
		boolean status=false;;
		b.setSelectedstation(dst);
		Session hs=sf.getCurrentSession();
		try
		{
		hs.update(b);
		status=true;
		}
		catch(Exception e)
		{
			e.toString();
		}
		return status;
	}
	
}
