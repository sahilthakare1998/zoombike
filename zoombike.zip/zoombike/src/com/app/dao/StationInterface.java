package com.app.dao;

import java.util.List;

import com.app.pojos.Bikes;
import com.app.pojos.Station;

public interface StationInterface {
public List<Station> StationList(String latitude,String Longitude);
public List<Bikes> getBikes(int id );
}
