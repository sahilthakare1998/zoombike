package com.app.dao;

import java.util.List;

import com.app.pojos.Admin;
import com.app.pojos.Bikes;
import com.app.pojos.Logs;
import com.app.pojos.Station;

public interface StationBikeProcessInterface {
public Station AddStation(Station s,String  a);
public Bikes AddBike(Bikes B,int id);
public String  RemoveStation(int id);
public String RemoveBike(int sid,int bid);
public List<Station> StationList();
public List<Bikes> BikeList();
public String updatestation(Station s,int id);
public String updatebike(Bikes s,int id);
public Bikes checkBike(int sid,int bid);
public Station checkStation(int sid);
public Admin addadmin(String nm);
public Station addupstation(int sid); 
public Logs mainatainLogs(int uid,Bikes b,Station src,Station dst );
public boolean changestation(Bikes b,Station dst);
}
