package com.app.dao;

import com.app.pojos.Admin;
import com.app.pojos.User;

public interface RegsiterInterface {
public String Regsiter(User u);
public User auntheticateUser(String login, String password);
public Admin auntheticateAdmin(String login, String password);
}
