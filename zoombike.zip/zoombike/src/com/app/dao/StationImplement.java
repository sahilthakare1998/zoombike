package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Bikes;
import com.app.pojos.Station;
@Repository
@Transactional
public class StationImplement implements StationInterface {

	@Autowired
	private SessionFactory sf;
	@Override
	public List<Station> StationList(String latitude,String Longitude) {
	
		String jpql="select distinct a from Station a join fetch a.Bikelist where (((acos(sin(((:latitude)*pi()/180)) * sin((a.latitude*pi()/180))+cos(((:latitude)*pi()/180)) * cos((a.latitude*pi()/180)) * cos((((:longitude)- a.longitude)*pi()/180))))*180/pi())*60*1.1515) <=5000  and a.activeStatus=:id";
		return sf.getCurrentSession().createQuery(jpql,Station.class).setParameter("latitude",Double.parseDouble(latitude)).setParameter("longitude",Double.parseDouble(Longitude)).setParameter("id",1).getResultList();
	
		//return sf.getCurrentSession().createQuery("select d from Station d join fetch d.Bikelist where d.latitude=:lat and longitude=:lon",Station.class).setParameter("lat",Double.parseDouble(latitude)).setParameter("lon",Double.parseDouble(Longitude)).getResultList();
		}
	@Override
	public List<Bikes> getBikes(int id) {
		String jpql="select b from Bikes b where b.selectedstation.id= :id and  b.availableStatus=:id1 and b.condit=:cond";
		return sf.getCurrentSession().createQuery(jpql,Bikes.class).setParameter("id",id).setParameter("cond","working").setParameter("id1",1).getResultList();
	}

}

//join fetch b.Station where b.id =:id               join fetch b.selectedstation