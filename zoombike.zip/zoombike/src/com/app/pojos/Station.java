package com.app.pojos;
//import javax.persistence.CascadeType;
//import javax.persistence.OneToMany;
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.List;
import javax.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "station2")
public class Station implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true)
	private Integer id;

	@NotNull
	@Column(name = "station_name", unique = true)
	private String numPoint;

	
	@Column(name = "free_bikes")
	private Integer freeBikes;

	@NotNull
	@Digits(integer = 2, fraction = 8)
	@Column(name = "longitude")
	private Double longitude;

	@NotNull
	@Digits(integer = 2, fraction = 8)
	@Column(name = "latitude")
	private Double latitude;

	@NotBlank
	@Column(name = "address_mark")
	private String addressMark;

	@Column(name = "active_status")
	private Integer activeStatus;

	@Column(name = "description")
	private String description;
	@ManyToOne // mandatory
	@JoinColumn(name = "admin_id") 
	private Admin admin;
	
	@OneToMany(mappedBy = "selectedstation", cascade = CascadeType.ALL,fetch = FetchType.EAGER )
	private List<Bikes> Bikelist= new ArrayList<Bikes>();
	
	
	public Admin getAdmin() {
		return admin;
	}


	public void setAdmin(Admin admin) {
		this.admin = admin;
	}


	public Station() {
		super();
	}
	
	
	public Station(String numPoint, Integer freeBikes, Double longitude, Double latitude, String addressMark,
			Integer activeStatus, String description) {
		super();
		this.numPoint = numPoint;
		this.freeBikes = freeBikes;
		this.longitude = longitude;
		this.latitude = latitude;
		this.addressMark = addressMark;
		this.activeStatus = activeStatus;
		this.description = description;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNumPoint() {
		return numPoint;
	}

	public void setNumPoint(String numPoint) {
		this.numPoint = numPoint;
	}

	public Integer getFreeBikes() {
		return freeBikes;
	}

	public void setFreeBikes(Integer freeBikes) {
		this.freeBikes = freeBikes;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getAddressMark() {
		return addressMark;
	}

	public void setAddressMark(String addressMark) {
		this.addressMark = addressMark;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public List<Bikes> getBikelist() {
		return Bikelist;
	}

	public void setBikelist(List<Bikes> bikelist) {
		Bikelist = null;
	}

	@Override
	public String toString() {
		return "Station [id=" + id + ", numPoint=" + numPoint + ", freeBikes=" + freeBikes + ", longitude=" + longitude
				+ ", latitude=" + latitude + ", addressMark=" + addressMark + ", activeStatus=" + activeStatus
				+ ", description=" + description + ", Bikelist=" + Bikelist + "]";
	}
	
	

	// helpers method
	public void addBikes(Bikes b) {
		Bikelist.add(b);
		b.setSelectedstation(this); 
	}
	
	// helpers method
	public void removeBikes(Bikes b) {
		Bikelist.remove(b);
		b.setSelectedstation(null);
	}
}
