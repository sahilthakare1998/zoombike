package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

@Entity
public class Admin {
	private int id;
	private String name;
	private String password;
	private List<Station> station =new ArrayList<Station>();
///////////////////////////////////////////////////
public Admin() {
	System.out.println("in admin constructotr");
}
/////////////////////////////////////////////////////
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@OneToMany(mappedBy = "admin", cascade = CascadeType.ALL,fetch = FetchType.EAGER )
public List<Station> getStation() {
	return station;
}
public void setStation(List<Station> station) {
	this.station = station;
}
@NotNull
@Column(name = "Admin_name", unique = true)
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@NotNull
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
//////////////////////////////////////////////////
public void addStation(Station s) {
	station.add(s);
	s.setAdmin(this); 
}

// helpers method
public void removeStation(Station s) {
	station.remove(s);
	s.setAdmin(null); 
}
////////////////////////////////////////////////////
}
