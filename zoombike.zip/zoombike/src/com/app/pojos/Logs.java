package com.app.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "LogTable")
public class Logs {
	private int rid;
	private String src_Station;
	private String dst_Station;
	private String number;
	//private Station station;
	private Integer bikeid;
	private Integer uid;
	
	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	
	public Logs(String src_Station, String dst_Station, String number, int bike, int uid) {
		super();
		this.src_Station = src_Station;
		this.dst_Station = dst_Station;
		this.number = number;
		this.bikeid = bike;
		this.uid = uid;
	}

	public Logs() {
		super();
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true)
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getSrc_Station() {
		return src_Station;
	}
	public void setSrc_Station(String src_Station) {
		this.src_Station = src_Station;
	}

	public String getDst_Station() {
		return dst_Station;
	}
	public void setDst_Station(String dst_Station) {
		this.dst_Station = dst_Station;
	}

	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	/*@NotBlank
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Station_Id")
	public Station getStation() {
		return station;
	}
	public void setStation(Station station) {
		this.station = station;
	}*/
	public int getBikeid() {
		return bikeid;
	}

	public void setBikeid(int bikeid) {
		this.bikeid = bikeid;
	}
	
	
}
