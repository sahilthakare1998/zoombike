package com.app.pojos;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "users")
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private String login;
	private String email;
	private String password;
	private String retypePassword;
	private String firstName;
	private String lastName;
	private String tel;
	private String gender;
	private Date birth;
    private Address address;
	public User() {
		super();
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@NotBlank
	@Column(name = "login",unique=true)
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	@NotBlank
	@Column(name = "email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@NotBlank
	@Column(name = "password")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@NotBlank
	@Transient
	public String getRetypePassword() {
		return retypePassword;
	}
	public void setRetypePassword(String retypePassword) {
		this.retypePassword = retypePassword;
	}
	@NotBlank
	@Column(name = "first_name")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@NotBlank
	@Column(name = "last_name")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@NotBlank
	@Column(name = "tel")
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	@NotBlank
	@Column(name = "gender")
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Column(name = "birth")
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="address_id")
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public void addAddress(Address a) {
		this.setAddress(a);
		a.setUser(this);
	}


	public void removeAddress(Address a) {
		this.setAddress(null);
		a.setUser(null);

	}
	public User(String login, String email, String password, String retypePassword, String firstName, String lastName,
			String tel, String gender, Date birth, Address address) {
		super();
		this.login = login;
		this.email = email;
		this.password = password;
		this.retypePassword = retypePassword;
		this.firstName = firstName;
		this.lastName = lastName;
		this.tel = tel;
		this.gender = gender;
		this.birth = birth;
		this.address = address;
	}
	public User(int i, String login2, String em, String pass, String cp, String fnm, String lnm, String ph, String city,
			String country, String gender2, String licience) {
		// TODO Auto-generated constructor stub
	}
	public User(int id, String login, String email, String password, String retypePassword, String firstName,
			String lastName, String tel, String gender, Date birth, Address address) {
		super();
		this.id = id;
		this.login = login;
		this.email = email;
		this.password = password;
		this.retypePassword = retypePassword;
		this.firstName = firstName;
		this.lastName = lastName;
		this.tel = tel;
		this.gender = gender;
		this.birth = birth;
		this.address = address;
	}

	
}
