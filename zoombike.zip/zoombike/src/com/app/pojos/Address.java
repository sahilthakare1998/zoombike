package com.app.pojos;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.validator.constraints.NotBlank;
@Entity
public class Address {
	
  private int id;
private String street;
private String city;
private String country;
private String Pincode;
private User user;
public Address() {}
@NotBlank
@Column(name = "Street")
public String getStreet() {
return street;
}
public void setStreet(String street) {
this.street = street;
}
@NotBlank
@Column(name = "country")
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
@NotBlank
@Column(name = "city")
public String getCity() {
return city;
}
@OneToOne(mappedBy="address")
public User getUser() {
return user;
}
public void setUser(User user) {
this.user = user;
}
public void setCity(String city) {
this.city = city;
}

public Address(String street, String city, String country, String pincode) {
	super();
	this.street = street;
	this.city = city;
	this.country = country;
	Pincode = pincode;
}
public Address(int id, String street, String city, String country, String pincode) {
	super();
	this.id = id;
	this.street = street;
	this.city = city;
	this.country = country;
	Pincode = pincode;
}
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "id", unique = true)
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
@NotBlank
@Column(name = "pincode")
public String getPincode() {
	return Pincode;
}

public void setPincode(String pincode) {
	Pincode = pincode;
}

@Override
public String toString() {
	return "Address [id=" + id + ", street=" + street + ", city=" + city + ", country=" + country + ", Pincode="
			+ Pincode + ", user=" + user + "]";
}

}
