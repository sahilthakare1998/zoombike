package com.app.pojos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "bikes")
public class Bikes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true)
	private Integer id;

	@NotBlank
	@Column(name = "number")
	private String number;

	@NotBlank
	@Column(name = "description")
	private String description;

	
	
	@Column(name = "available_status")
	private Integer availableStatus;
	
	@NotBlank
	@Column(name = "condit")
	private String condit;
	

	@Column(name = "price")
	private Double price;
    
	@ManyToOne // mandatory
	@JoinColumn(name = "s_id") 
	private Station selectedstation;
	
	public Bikes() {
		super();
	}

	
	public Bikes(String number, String description, Integer availableStatus, String condit, Double price) {
		super();
		this.number = number;
		this.description = description;
		this.availableStatus = availableStatus;
		this.condit = condit;
		this.price = price;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getVin() {
		return number;
	}

	public void setVin(String vin) {
		this.number = vin;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	

	public Integer getAvailableStatus() {
		return availableStatus;
	}

	public void setAvailableStatus(Integer availableStatus) {
		this.availableStatus = availableStatus;
	}

	public String getCondit() {
		return condit;
	}

	public void setCondit(String condit) {
		this.condit = condit;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	

	public Station getSelectedstation() {
		return selectedstation;
	}

	public void setSelectedstation(Station selectedstation) {
		this.selectedstation = selectedstation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((availableStatus == null) ? 0 : availableStatus.hashCode());
		result = prime * result + ((condit == null) ? 0 : condit.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((selectedstation == null) ? 0 : selectedstation.hashCode());
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Bikes))
			return false;
		Bikes other = (Bikes) obj;
		if (availableStatus == null) {
			if (other.availableStatus != null)
				return false;
		} else if (!availableStatus.equals(other.availableStatus))
			return false;
		if (condit == null) {
			if (other.condit != null)
				return false;
		} else if (!condit.equals(other.condit))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (selectedstation == null) {
			if (other.selectedstation != null)
				return false;
		} else if (!selectedstation.equals(other.selectedstation))
			return false;
		return true;
	}
}