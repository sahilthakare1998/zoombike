package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.StationBikeProcessInterface;
import com.app.dao.StationInterface;
import com.app.pojos.Bikes;

@Controller
@Scope("session")
@RequestMapping("/price")
public class priceController {
 
	

	@Autowired
	private StationInterface dao;
	@Autowired
	StationBikeProcessInterface dao1;
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	@GetMapping("/pricelist") // template URI variable
	public String price() {
		System.out.println("In price get controller");

		return "/station/bike";
	}
	

	
	@PostMapping("/pricelist") // template URI variable
	public String price(@RequestParam int bikeid,@RequestParam int time,HttpSession session) {
		int sid=(int)session.getAttribute("station_details");
		Bikes b=dao1.checkBike(sid, bikeid);
		session.setAttribute("bike",b);
		System.out.println("In price post controller");
		System.out.println(b.getPrice()+" "+b.getId());
		System.out.println(time);
		session.setAttribute("station_data",dao1.checkStation(sid));
		System.out.println(b.getPrice()*time);
		session.setAttribute("price_details", b.getPrice()*time);
		session.setAttribute("time_details", time);

		//List<Bikes> bikelist= dao.getBikes(station);
	//	System.out.println(station);

		//session.setAttribute("bike_details",bikelist);
		//System.out.println(bikelist);
		return "redirect:/payment/paynow" ;
	}
}
