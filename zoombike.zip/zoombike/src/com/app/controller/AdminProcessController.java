package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.RegsiterInterface;
import com.app.dao.StationBikeProcessInterface;
import com.app.pojos.Admin;
import com.app.pojos.Bikes;
import com.app.pojos.Station;

@Controller
@RequestMapping("/Process")
public class AdminProcessController {
	@Autowired
	private RegsiterInterface dao;
	@Autowired
	private StationBikeProcessInterface dao1;
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/Admin/login";
	
	}
	
	public AdminProcessController() {
		System.out.println("In Admin Process Controller");
	}
	@GetMapping("/form")
	public String processUser() {
		System.out.println("in login getmapping");
		return "/Admin/form";
	}
	///////////////////////////////////////////////////
	@GetMapping("/add")
	public String addStation() {
		System.out.println("in admin addstation get process controller");
		return "/Admin/addStation";
	}
	
	@PostMapping("/add")
	public String addStation(@RequestParam String station_name,@RequestParam String freebikes, @RequestParam String latitude,@RequestParam String longitude,@RequestParam String address,@RequestParam String status,@RequestParam String desp,HttpSession hs) {
		Station s=new Station(station_name,Integer.parseInt(freebikes),Double.parseDouble(latitude) ,Double.parseDouble(longitude),address,Integer.parseInt(status),desp);
		String nm=hs.getAttribute("admin_name").toString();
		System.out.println("admin name:"+nm);
		dao1.AddStation(s,nm);
	
		System.out.println("in admin addstation post process controller");
		return "/Admin/form";
	}
	/////////////////////////////////////////////////////////
	/*@GetMapping("/remove")
	public String RemoveStation() {
		System.out.println("in admin remove  get process controller");
		return "/Admin/removeStation";
	}*/
	@GetMapping("/remove")
	public String RemoveStation(@RequestParam String stationId) {
		System.out.println("in admin remove  post process controller");
		dao1.RemoveStation(Integer.parseInt(stationId));
		return "/Admin/form";
	}
	////////////////////////////////////////////////////////////
	@GetMapping("/addbike")
	public String addbike() {
		System.out.println("in admin addbike get process controller");
		return "/Admin/addBike";
	}
	@PostMapping("/addbike")
	public String addbike(@RequestParam String stationId,@RequestParam String description,@RequestParam String bikenumber,@RequestParam String status,@RequestParam String condition,@RequestParam String price) {
		Bikes b=new Bikes(bikenumber,description,Integer.parseInt(status),condition,Double.parseDouble(price));
		dao1.AddBike(b, Integer.parseInt(stationId));
		System.out.println("in admin addbike  post process controller");
		
		return "/Admin/form";
	}
	///////////////////////////////////////////////////////////////
	/*@GetMapping("/removebike")
	public String removebike() {
	
		System.out.println("in admin removebike process controller");
		return "/Admin/removeBike";
	}
	*/
	@GetMapping("/removebike")
	public String removebike(@RequestParam String stationId,@RequestParam String BikeId) {
		System.out.println(dao1.RemoveBike(Integer.parseInt(stationId),Integer.parseInt(BikeId)));
		System.out.println("in admin removebike process controller");
		return "/Admin/form";
	}
	//////////////////////////////////////////////////////////////
	
	@GetMapping("/updateStation")
	public String UpdateStation() {
	
		System.out.println("in admin update process controller");
		return "/Admin/updateStation";
	}

	@PostMapping("/updateStation")
	public String UpdateStation(@RequestParam String stationId,@RequestParam String station_name,@RequestParam String freebikes, @RequestParam String latitude,@RequestParam String longitude,@RequestParam String address,@RequestParam String status,@RequestParam String desp,HttpSession hs) {
		Station s=new Station(station_name,Integer.parseInt(freebikes),Double.parseDouble(latitude) ,Double.parseDouble(longitude),address,Integer.parseInt(status),desp);
		String nm=hs.getAttribute("admin_name").toString();
		Station s1=dao1.checkStation(Integer.parseInt(stationId));
		if(s1!=null)
		{
		dao1.addadmin(nm).addStation(s);
		System.out.println(dao1.updatestation(s, Integer.parseInt(stationId)));
		}
		System.out.println("in admin update process controller");
		return "/Admin/updateStation";
	}
	////////////////////////////////////////////////////////////////
	@GetMapping("/updateBike")
	public String UpdateBike() {
		System.out.println("in admin update process controller");
		return "/Admin/updateBike";
	}

	@PostMapping("/updateBike")
	public String UpdateBike(@RequestParam String BikeId,@RequestParam String stationId,@RequestParam String description,@RequestParam String bikenumber,@RequestParam String status,@RequestParam String condition,@RequestParam String price) {
		Bikes b=new Bikes(bikenumber,description,Integer.parseInt(status),condition,Double.parseDouble(price));
		b.setId(Integer.parseInt(BikeId));
		Bikes b1=dao1.checkBike(Integer.parseInt(stationId), Integer.parseInt(BikeId));
		if(b1!=null)
		{
			Station s1=dao1.addupstation(Integer.parseInt(stationId));
			s1.addBikes(b);
		System.out.println(dao1.updatebike(b, Integer.parseInt(stationId)));
		}
		System.out.println("in admin update process controller");
		return "/Admin/form";
	}

	
	///////////////////////////////////////////////////////////////
	@GetMapping("/showstation")
	public String showStation(HttpSession hs) { 
		//System.out.println(dao1.StationList());
hs.setAttribute("list",dao1.StationList());

		System.out.println("in admin update process controller");
		return "/Admin/showStation";
	}
	/*@PostMapping("/removebike")
	public String removebike(@RequestParam String stationId,@RequestParam String BikeId) {
		System.out.println(dao1.RemoveBike(Integer.parseInt(stationId),Integer.parseInt(BikeId)));
		System.out.println("in admin removebike process controller");
		return "/Admin/form";
	}
	*/
	
/////////////////////////////////////////////////////////////////////////
	
	@GetMapping("/showBike")
	public String showBike(HttpSession hs,@RequestParam String stationId) { 
		System.out.println(dao1.BikeList());
hs.setAttribute("list1",dao1.BikeList());
hs.setAttribute("station",stationId);
		System.out.println("in admin update process controller");
		return "/Admin/showBike";
	}
}
