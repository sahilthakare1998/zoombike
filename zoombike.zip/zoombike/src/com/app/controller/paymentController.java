package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.dao.StationInterface;

@Controller
@RequestMapping("/payment")
public class paymentController {
	
	@Autowired
	private StationInterface dao;
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	@GetMapping("/paynow")
	public String payment() {
		System.out.println("in paynow getmapping");
		return "/station/price";
		
	}  
	

	@PostMapping("/paynow")
	public String paymentdone() {
		System.out.println("in paynow postmapping");
		return "redirect:/email";
		
	}  
}
