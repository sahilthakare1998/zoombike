package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.StationBikeProcessInterface;
import com.app.dao.StationInterface;
import com.app.pojos.Bikes;
import com.app.pojos.Station;
import com.app.pojos.User;

@Controller
@Scope("session")
@RequestMapping("/bike")
public class BikeController {
	@Autowired
	private StationBikeProcessInterface dao1;
	@Autowired
	private StationInterface dao;
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	@GetMapping("/list") // template URI variable
	public String bikes() {
		System.out.println("In bikes get controller");
		return "/station/list";
	}
	
	
	
	@PostMapping("/list") // template URI variable
	public String bikes(@RequestParam int station,HttpSession session) {
		System.out.println("In bikes post controller");
		System.out.println(station);
	
		List<Bikes> bikelist= dao.getBikes(station);
		System.out.println(station);
		session.setAttribute("station_details",station);

		session.setAttribute("bike_details",bikelist);
		//System.out.println(bikelist);
		return "redirect:/price/pricelist" ;
	}
	
	/*
	@PostMapping("/list") // template URI variable
	public String bikes(@RequestParam int station,Model map) {
		System.out.println("In bikes post controller");
		System.out.println(station);

		List<Bikes> bikelist= dao.getBikes(station);
		System.out.println(station);

		map.addAttribute("bike_details",bikelist);
		//System.out.println(bikelist);
		return "/station/bike" ;
	}
	*/
	@GetMapping("/list1") // template URI variable
	public String bikes1() {
		System.out.println("In bikes get controller");
		return "/station/list1";
	}
	@PostMapping("/list1") // template URI variable
	public String bikes1(@RequestParam int station,HttpSession hs) {
		Bikes b=(Bikes)hs.getAttribute("bike");
		Station s=(Station)hs.getAttribute("station_data");
		User u=(User)hs.getAttribute("user");
		System.out.println("deatils:::"+"user id"+u.getId()+"source station"+s.getNumPoint()+"bike id"+b.getId()+"bikle number"+b.getVin());
		System.out.println("dest station:"+dao1.checkStation(station));
		hs.setAttribute("dstation_data",dao1.checkStation(station));
		dao1.mainatainLogs(u.getId(), b,s, dao1.checkStation(station));
		if(dao1.changestation(b, dao1.checkStation(station)))
		    return "redirect:/user/login";
		else
		    return "redirect:/station/list1";
	}
	}

