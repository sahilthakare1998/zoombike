package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.RegsiterInterface;
import com.app.pojos.Admin;
import com.app.pojos.User;

@Controller
@RequestMapping("/Admin")
public class AdminController {
	@Autowired
	private RegsiterInterface dao;
	@GetMapping("/login")
	public String loginUser() {
		System.out.println("in login getmapping");
		return "/Admin/login";
	}
	
	public AdminController() {
		System.out.println("in admin controller");

	}

	@PostMapping("/login")
	public String loginUser(@RequestParam String login,@RequestParam String pass,Model map,HttpSession hs) {
		System.out.println("in login postmapping");
		try{
			Admin u=dao.auntheticateAdmin(login, pass);
            hs.setAttribute("admin_name",u.getName());
			System.out.println("in login succesull");
		map.addAttribute("msg","login succesfull");
		return "redirect:/Process/form";	
		}
		catch(RuntimeException e){
			System.out.println("login unsuccesfull");
			map.addAttribute("msg", "Invalid Login");

			return "/Admin/login";
		}
		
	}

	
}
