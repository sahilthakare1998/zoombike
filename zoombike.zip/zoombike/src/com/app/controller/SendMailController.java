package com.app.controller;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.pojos.*;

@Scope("session")
@Controller
@RequestMapping("/email")
public class SendMailController {
	@Autowired
	private JavaMailSender sender;
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	@RequestMapping
	public String showForm(Model m)
	{
		System.out.println("in mail get controller");
		m.addAttribute(new Email());
		return "/Email/send_mail";
	}
	@RequestMapping(method=RequestMethod.POST)
	public String processForm(@ModelAttribute Email em,BindingResult res,HttpSession session)
	{
		Random r= new Random();
		String randomnumber= String.format("%04d",Integer.valueOf(r.nextInt(1001))) ;
		System.out.println(randomnumber);
		System.out.println(em.getDestEmail()+"  "+em.getMessage());
		SimpleMailMessage mesg=new SimpleMailMessage();
		mesg.setTo(em.getDestEmail());
		mesg.setSubject("Your otp for starting your ride.");
		//mesg.setText(em.getMessage());
		mesg.setText(randomnumber);
		session.setAttribute("otp_details",randomnumber);

		sender.send(mesg);
		return "redirect:/otp/otpcheck";
	}

}
