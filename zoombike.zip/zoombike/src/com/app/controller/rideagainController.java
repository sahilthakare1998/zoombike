package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.pojos.Bikes;
import com.app.pojos.Station;
import com.app.pojos.User;

@Controller
@Scope("session")
@RequestMapping("/rideagain")
public class rideagainController {
	
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	@GetMapping("/ride") // template URI variable
	public String rideagain() {
		System.out.println("In rideagain get controller");
		return "/station/payed";
	}

	@PostMapping("/ride") // template URI variable
	public String rideagainpost(HttpSession hs) {
	
		System.out.println("In rideagain get controller");
		//return "redirect:/station/ride";
		return "redirect:/station/destLocation";
	}
}
