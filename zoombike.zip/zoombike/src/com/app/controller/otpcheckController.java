package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@Scope("session")
@RequestMapping("/otp")
public class otpcheckController {
	
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	@GetMapping("/otpcheck") // template URI variable
	public String otpcheckget() {
		System.out.println("In otp get controller");

		return "/station/otp";
	}

	@PostMapping("/otpcheck") // template URI variable
	public String otpcheckpost(@RequestParam String otp,HttpSession session) {
		System.out.println("In otp post controller");
		System.out.println(session.getAttribute("otp_details"));
		if(otp.equals(session.getAttribute("otp_details")))
		{
			System.out.println("In otp check");

		return "redirect:/rideagain/ride";
		}
		else return "/station/otp";
	}

}
