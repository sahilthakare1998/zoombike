package com.app.controller;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.RegsiterInterface;
import com.app.pojos.Address;
import com.app.pojos.User;
import java.text.ParseException;

@Controller
@RequestMapping("/user")
public class userController {
	@Autowired
	private RegsiterInterface dao;
	
	public userController() {
		super();
		System.out.println("in usercontroll constructor");
	}
	
	@GetMapping("/login")
	public String loginUser() 
	{
		
		System.out.println("in login getmapping");
		return "/user/login";
	}
	
	@PostMapping("/login")
	public String loginUser(@RequestParam String login,@RequestParam String pass,Model map,HttpSession hs) {
		System.out.println("in login postmapping");
		try{
		User u=	dao.auntheticateUser(login, pass);
		map.addAttribute("user_details",u );
		hs.setAttribute("user",u);///extra added
		map.addAttribute("msg","login succesfull");
		return "redirect:/station/ride";
		}
		catch(RuntimeException e){
			System.out.println("login unsuccesfull");
			map.addAttribute("msg", "Invalid Login");

			return "/user/login";
		}
		
	}

	@GetMapping("/register")
	public String registerUser(User u) {
		System.out.println("in register user's getmapping");
		return "/user/register";
		}
	
	@PostMapping("/register")
	public String registerUser(@RequestParam String login ,@RequestParam String fnm,@RequestParam String lnm,@RequestParam String pass,@RequestParam String cp,@RequestParam String em,@RequestParam String ph,@RequestParam String city,@RequestParam String country,@RequestParam String gender,@RequestParam String street,@RequestParam String pincode,@RequestParam String date)
		{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		System.out.println("in register user's postmapping");
		Address a=new Address(city,country,pincode,street);
		User u;
		try {
			u = new User(login,em,pass,cp,fnm,lnm,ph,gender,sdf.parse(date),a);
			u.addAddress(a);
			dao.Regsiter(u);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
		System.out.println("Registered successfully");
		return "/user/login";
		}
	
}
