package com.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.StationInterface;
import com.app.pojos.Bikes;
import com.app.pojos.Station;

@Controller
@RequestMapping("/station")
public class stationController {
	@Autowired
	private StationInterface dao;
	
	public stationController() {
		
		System.out.println("In station Controller");
	}
	
	@GetMapping("/login")
	public String login() {
		System.out.println("In dst station ");
		
	
		return "redirect:/user/login";
	
	}
	
	
	

	@GetMapping("/ride") // template URI variable
	public String showform() {
		System.out.println("In station form");
		
	
		return "/station/ride";
	}
	
	@PostMapping("/ride")
	public String processform(@RequestParam String latitude,@RequestParam String ln,@RequestParam String tp ,Model map,RedirectAttributes flashmap,HttpSession session) {
		System.out.println("In station  process form");
		try {
		List<Station> stationlist=dao.StationList(latitude, ln);
	
		System.out.println("In station  process form1");
 System.out.println(stationlist);
		flashmap.addFlashAttribute("data",stationlist );
		session.setAttribute("data",stationlist);
		return "redirect:/bike/list";
		} catch (RuntimeException e) {
			
			return "/station/ride";
		}
	}
	@GetMapping("/destLocation")
	public String showdst() {
		System.out.println("In dst station ");
		
	
		return "/station/destLocation";
	}
	@PostMapping("/destLocation")
	public String showdst1(@RequestParam String latitude,@RequestParam String ln,@RequestParam String tp ,Model map,RedirectAttributes flashmap,HttpSession session)
			{
		System.out.println("In station  process form");
		try {
		List<Station> stationlist=dao.StationList(latitude, ln);
	
		System.out.println("In station  process form1");
 System.out.println(stationlist);
		flashmap.addFlashAttribute("data1",stationlist );
        session.setAttribute("data1", stationlist);
		return "redirect:/bike/list1";
		} catch (RuntimeException e) {
			return "/station/destLocation";		
			}
		
	}
	
}
